import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  RotateCw,
  Save,
  Search,
  Plus,
  Trash2,
  Download,
  Sliders,
  Sparkles,
  Terminal,
  CheckCircle2,
} from 'lucide-react';

interface Story {
  id: string;
  title: string;
  start: number;
  end: number;
  color: string;
}

interface TranscriptEntry {
  id: string;
  speaker: string;
  time: string;
  seconds: number;
  text: string;
}

const INITIAL_STORIES: Story[] = [
  { id: '1', title: 'Community News & Youth Programs', start: 10.5, end: 125.0, color: '#315c85' },
  { id: '2', title: 'West Philly Yemeni Coffee Shop Feature', start: 135.0, end: 320.0, color: '#386b59' },
  { id: '3', title: 'Tech Monopolies & Digital History', start: 330.0, end: 490.0, color: '#795d31' },
];

const TRANSCRIPT_DATA: TranscriptEntry[] = [
  {
    id: 't1',
    speaker: 'Speaker 2',
    time: '00:10.560',
    seconds: 10.56,
    text: "This is Block by Block, a community news program where we explore issues affecting the Philadelphia area with news reports from members of the community. I'm Sophia Mattia.",
  },
  {
    id: 't2',
    speaker: 'Speaker 3',
    time: '00:19.679',
    seconds: 19.679,
    text: "And I'm Abby Cruz. In the next half hour, we'll hear stories from our community news reporters about the importance of diversity among archivists and research librarians, a new Yemeni-style coffee shop in West Philly, and a Northwest Philly nonprofit connecting people with nature.",
  },
  {
    id: 't3',
    speaker: 'Speaker 2',
    time: '00:39.630',
    seconds: 39.63,
    text: "Now you can make video calls to anyone in the world from your phone, download large files in seconds, or stream 4K movies to your TV. But a handful of big tech companies also now control a huge portion of the internet.",
  },
];

export default function App() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(19.68);
  const [totalDuration] = useState(600.0); // 10 minutes demo
  const [stories, setStories] = useState<Story[]>(INITIAL_STORIES);
  const [selectedStoryId, setSelectedStoryId] = useState<string>('1');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'preview' | 'setup'>('preview');

  // Playback timer
  useEffect(() => {
    let interval: any = null;
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTime((prev) => {
          if (prev >= totalDuration) {
            setIsPlaying(false);
            return 0;
          }
          return prev + 0.5;
        });
      }, 500);
    }
    return () => clearInterval(interval);
  }, [isPlaying, totalDuration]);

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    const ms = Math.floor((secs % 1) * 1000);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}.${ms.toString().padStart(3, '0')}`;
  };

  const selectedStory = stories.find((s) => s.id === selectedStoryId) || stories[0];

  return (
    <div id="app_root" className="min-h-screen bg-[#121417] text-[#f0f3f6] flex flex-col font-sans select-none">
      {/* Top Application Header */}
      <header id="app_header" className="h-10 bg-[#181b20] border-b border-[#282c35] px-4 flex items-center justify-between text-xs">
        <div className="flex items-center gap-3">
          <span className="font-semibold text-white tracking-wide">
            Radio & TV Segmenter <span className="text-[#38bdf8] font-mono text-[11px]">v2.1.0-beta</span>
          </span>
          <span className="text-[#8b949e]">|</span>
          <span className="text-[#8b949e] truncate max-w-sm">
            Project: BxB-5-27-2026.rtvs (Broadcast Dark Modern Theme)
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="tab_preview_btn"
            onClick={() => setActiveTab('preview')}
            className={`px-2.5 py-1 rounded text-xs transition-colors ${
              activeTab === 'preview'
                ? 'bg-[#007acc] text-white font-medium'
                : 'text-[#8b949e] hover:text-white'
            }`}
          >
            Live UI Preview
          </button>
          <button
            id="tab_setup_btn"
            onClick={() => setActiveTab('setup')}
            className={`px-2.5 py-1 rounded text-xs flex items-center gap-1.5 transition-colors ${
              activeTab === 'setup'
                ? 'bg-[#007acc] text-white font-medium'
                : 'text-[#8b949e] hover:text-white'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            Desktop Launch Guide
          </button>
        </div>
      </header>

      {activeTab === 'setup' ? (
        <main className="flex-1 max-w-4xl w-full mx-auto p-8 space-y-6">
          <div className="bg-[#181b20] border border-[#282c35] rounded-xl p-6">
            <h2 className="text-xl font-bold text-white flex items-center gap-2 mb-2">
              <CheckCircle2 className="w-6 h-6 text-[#38bdf8]" />
              Modern Dark Theme v2.1.0-beta Integrated
            </h2>
            <p className="text-sm text-[#8b949e] leading-relaxed mb-6">
              All targeted QSS styles, theme tokens, and dynamic palette hooks have been integrated into your Python codebase (<code className="text-[#38bdf8]">playback_preferences.py</code>, <code className="text-[#38bdf8]">prs_shared.py</code>, and <code className="text-[#38bdf8]">ui_layout.py</code>).
            </p>

            <div className="space-y-4">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-[#38bdf8]">
                Running with the new styling on your desktop:
              </h3>
              <div className="bg-[#121417] border border-[#282c35] rounded-lg p-4 font-mono text-sm space-y-2">
                <p className="text-[#8b949e]"># 1. Install modern theme and Mica styling packages:</p>
                <div className="bg-[#1e222a] text-[#38bdf8] p-2.5 rounded border border-[#282c35]">
                  pip install pyqtdarktheme pywinstyles
                </div>

                <p className="text-[#8b949e] pt-2"># 2. Launch your segmenter application:</p>
                <div className="bg-[#1e222a] text-[#38bdf8] p-2.5 rounded border border-[#282c35]">
                  python RadioTVSegmenter.py
                </div>
              </div>

              <div className="p-4 bg-[#1e222a]/50 rounded-lg border border-[#282c35] text-xs text-[#8b949e] space-y-1">
                <p className="text-white font-medium">Why it was showing the old style previously:</p>
                <p>
                  • <code className="text-slate-300">playback_preferences.py</code> was executing an internal legacy <code className="text-slate-300">set_theme("dark")</code> stylesheet that overrode the new styling. We updated <code className="text-slate-300">set_theme()</code> to inject <code className="text-slate-300">TARGETED_QSS</code> directly.
                </p>
                <p>
                  • Waveform canvas elements and the interactive transcript viewer now strictly reference the centralized <code className="text-slate-300">ThemeTokens</code> zinc/slate palette.
                </p>
              </div>
            </div>
          </div>
        </main>
      ) : (
        <main className="flex-1 flex flex-col p-3 gap-3 overflow-hidden">
          {/* Section 1: Transport Control Ribbon */}
          <section id="transport_ribbon" className="bg-[#181b20] border border-[#282c35] rounded-xl p-3 flex items-center justify-between shadow-sm">
            <div className="flex items-center gap-3">
              {/* Pill-shaped Play Button */}
              <button
                id="play_button"
                onClick={() => setIsPlaying(!isPlaying)}
                className="bg-[#007acc] hover:bg-[#1a8cff] active:bg-[#005999] text-white px-5 py-1.5 rounded-full font-bold text-xs flex items-center gap-2 shadow transition-colors min-w-[84px] justify-center"
              >
                {isPlaying ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white" />}
                <span>{isPlaying ? 'Pause' : 'Play'}</span>
              </button>

              {/* Monospace Cyan Timecode Badge */}
              <div id="time_label" className="font-mono text-xs font-semibold text-[#38bdf8] bg-[#121417] border border-[#282c35] rounded-md px-3 py-1.5 min-w-[190px] text-center">
                {formatTime(currentTime)} / {formatTime(totalDuration)}
              </div>

              {/* Flat Skip Buttons */}
              <button
                id="skip_backward_button"
                onClick={() => setCurrentTime(Math.max(0, currentTime - 5))}
                className="text-[#8b949e] hover:text-[#f0f3f6] hover:bg-[#121417] border border-[#282c35] hover:border-[#007acc] px-2.5 py-1 rounded-full text-[11px] font-semibold flex items-center gap-1 transition-colors"
              >
                <RotateCcw className="w-3 h-3" />
                <span>5s</span>
              </button>
              <button
                id="skip_forward_button"
                onClick={() => setCurrentTime(Math.min(totalDuration, currentTime + 5))}
                className="text-[#8b949e] hover:text-[#f0f3f6] hover:bg-[#121417] border border-[#282c35] hover:border-[#007acc] px-2.5 py-1 rounded-full text-[11px] font-semibold flex items-center gap-1 transition-colors"
              >
                <span>5s</span>
                <RotateCw className="w-3 h-3" />
              </button>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[11px] text-[#8b949e] mr-2">Auto-saved to disk</span>
              <button
                id="quick_save_button"
                className="bg-[#1e222a] hover:bg-[#282c35] hover:border-[#38bdf8] text-[#f0f3f6] hover:text-white border border-[#282c35] px-3.5 py-1.5 rounded-md text-xs font-medium flex items-center gap-1.5 transition-colors"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Save Project</span>
              </button>
            </div>
          </section>

          {/* Section 2: Timeline Canvas & Waveform */}
          <section id="timeline_widget" className="bg-[#181b20] border border-[#282c35] rounded-xl overflow-hidden flex flex-col h-40">
            {/* Time Ruler */}
            <div className="h-6 bg-[#111317] border-b border-[#2c323d] relative px-2 flex items-center text-[10px] font-mono text-[#8a95a5]">
              <span className="absolute left-2">00:00:00</span>
              <span className="absolute left-1/4">00:02:30</span>
              <span className="absolute left-2/4">00:05:00</span>
              <span className="absolute left-3/4">00:07:30</span>
              <span className="absolute right-2">00:10:00</span>
            </div>

            {/* Waveform Canvas Area */}
            <div
              className="flex-1 bg-[#181b20] relative cursor-pointer overflow-hidden"
              onClick={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                const clickX = e.clientX - rect.left;
                const ratio = clickX / rect.width;
                setCurrentTime(ratio * totalDuration);
              }}
            >
              {/* Synthetic Waveform Lines */}
              <div className="absolute inset-0 flex items-center justify-between px-2 opacity-75">
                {Array.from({ length: 96 }).map((_, i) => {
                  const heightPercent = Math.min(
                    85,
                    Math.max(12, Math.sin(i * 0.28) * 35 + Math.cos(i * 0.7) * 25 + 30)
                  );
                  return (
                    <div
                      key={i}
                      className="w-1 bg-[#5a81a8] rounded-full mx-[1px]"
                      style={{ height: `${heightPercent}%` }}
                    />
                  );
                })}
              </div>

              {/* Story Segment Overlays on Waveform */}
              {stories.map((story) => {
                const leftPercent = (story.start / totalDuration) * 100;
                const widthPercent = ((story.end - story.start) / totalDuration) * 100;
                const isSelected = story.id === selectedStoryId;

                return (
                  <div
                    key={story.id}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedStoryId(story.id);
                      setCurrentTime(story.start);
                    }}
                    className={`absolute top-0 bottom-0 transition-all ${
                      isSelected
                        ? 'border-2 border-white'
                        : 'border border-sky-400/40 opacity-70 hover:opacity-100'
                    }`}
                    style={{
                      left: `${leftPercent}%`,
                      width: `${widthPercent}%`,
                      backgroundColor: story.color,
                      opacity: isSelected ? 0.65 : 0.4,
                    }}
                  >
                    <span className="absolute top-1 left-2 text-[10px] font-medium bg-black/60 px-1.5 py-0.5 rounded text-white truncate max-w-full">
                      {story.title}
                    </span>
                  </div>
                );
              })}

              {/* Playhead Red Indicator */}
              <div
                className="absolute top-0 bottom-0 w-[2px] bg-[#ff5c5c] pointer-events-none z-10 transition-all duration-100"
                style={{ left: `${(currentTime / totalDuration) * 100}%` }}
              >
                <div className="w-3 h-3 bg-[#ff5c5c] -ml-[5px] rotate-45 transform -translate-y-1" />
              </div>
            </div>
          </section>

          {/* Section 3: Lower Workspace (Split: Transcript & Story Cards) */}
          <div className="flex-1 grid grid-cols-1 md:grid-cols-12 gap-3 min-h-0 overflow-hidden">
            {/* Left: Interactive Transcript View */}
            <section id="transcript_panel" className="md:col-span-8 bg-[#181b20] border border-[#282c35] rounded-xl p-3 flex flex-col min-h-0">
              <div className="flex items-center gap-2 mb-3">
                <div className="relative flex-1">
                  <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-[#8b949e]" />
                  <input
                    id="transcript_search_input"
                    type="text"
                    placeholder="Search transcript..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-[#121417] border border-[#282c35] focus:border-[#38bdf8] rounded-md pl-8 pr-3 py-1.5 text-xs text-[#f0f3f6] outline-none"
                  />
                </div>
                <button
                  id="find_next_btn"
                  className="bg-[#1e222a] hover:bg-[#282c35] border border-[#282c35] px-3 py-1.5 rounded-md text-xs font-medium text-[#f0f3f6]"
                >
                  Find Next
                </button>
                <button
                  id="translate_button"
                  className="bg-[#1e222a] hover:bg-[#282c35] border border-[#282c35] px-3 py-1.5 rounded-md text-xs font-medium text-[#f0f3f6]"
                >
                  Translate...
                </button>
              </div>

              {/* Transcript Display Box */}
              <div
                id="transcript_view"
                className="flex-1 bg-[#121417] border border-[#282c35] rounded-lg p-3 overflow-y-auto space-y-3 text-xs leading-relaxed font-sans"
              >
                {TRANSCRIPT_DATA.map((entry) => {
                  const isCurrent =
                    currentTime >= entry.seconds && currentTime < entry.seconds + 20;

                  return (
                    <div
                      key={entry.id}
                      onClick={() => setCurrentTime(entry.seconds)}
                      className={`p-2 rounded-md transition-colors cursor-pointer ${
                        isCurrent
                          ? 'bg-[#1e222a] border border-[#007acc]/60'
                          : 'hover:bg-[#181b20]'
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-mono text-[#38bdf8] text-[11px] font-semibold">
                          {entry.time}
                        </span>
                        <span className="font-bold text-[#007acc] text-[11px]">
                          {entry.speaker}
                        </span>
                      </div>
                      <p className="text-[#f0f3f6]">{entry.text}</p>
                    </div>
                  );
                })}
              </div>
            </section>

            {/* Right: Story Cards & Segment Inspector */}
            <section id="stories_panel" className="md:col-span-4 bg-[#181b20] border border-[#282c35] rounded-xl p-3 flex flex-col min-h-0">
              <h3 className="text-xs font-semibold text-white uppercase tracking-wider mb-2">
                Stories & Segments
              </h3>

              {/* Story List Items */}
              <div id="story_list" className="flex-1 overflow-y-auto space-y-1.5 mb-3">
                {stories.map((story) => {
                  const isSelected = story.id === selectedStoryId;

                  return (
                    <div
                      key={story.id}
                      onClick={() => {
                        setSelectedStoryId(story.id);
                        setCurrentTime(story.start);
                      }}
                      className={`p-2.5 rounded-md border text-xs cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-[#1c2738] border-[#007acc] border-l-4 border-l-[#38bdf8] text-white font-medium'
                          : 'bg-[#181b20] border-[#282c35] border-l-4 border-l-[#007acc] text-[#f0f3f6] hover:bg-[#1e222a]'
                      }`}
                    >
                      <div className="font-semibold truncate">{story.title}</div>
                      <div className="text-[10px] text-[#8b949e] font-mono mt-0.5">
                        {formatTime(story.start)} – {formatTime(story.end)}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Selected Story Form Controls */}
              <div className="bg-[#121417] border border-[#282c35] rounded-lg p-3 space-y-2 text-xs">
                <div>
                  <label className="text-[10px] uppercase text-[#8b949e] font-semibold block mb-1">
                    Headline / Title:
                  </label>
                  <input
                    type="text"
                    value={selectedStory.title}
                    onChange={(e) => {
                      const newTitle = e.target.value;
                      setStories((prev) =>
                        prev.map((s) => (s.id === selectedStory.id ? { ...s, title: newTitle } : s))
                      );
                    }}
                    className="w-full bg-[#181b20] border border-[#282c35] focus:border-[#38bdf8] rounded px-2.5 py-1.5 text-xs text-white outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] uppercase text-[#8b949e] font-semibold block mb-1">
                      Start:
                    </label>
                    <input
                      type="text"
                      readOnly
                      value={formatTime(selectedStory.start)}
                      className="w-full bg-[#181b20] border border-[#282c35] rounded px-2 py-1 font-mono text-[11px] text-[#38bdf8]"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] uppercase text-[#8b949e] font-semibold block mb-1">
                      End:
                    </label>
                    <input
                      type="text"
                      readOnly
                      value={formatTime(selectedStory.end)}
                      className="w-full bg-[#181b20] border border-[#282c35] rounded px-2 py-1 font-mono text-[11px] text-[#38bdf8]"
                    />
                  </div>
                </div>

                <div className="pt-1 flex gap-2">
                  <button
                    id="add_story_btn"
                    onClick={() => {
                      const newId = (stories.length + 1).toString();
                      const newStory: Story = {
                        id: newId,
                        title: `Story ${newId}`,
                        start: currentTime,
                        end: Math.min(totalDuration, currentTime + 60),
                        color: '#674f7c',
                      };
                      setStories([...stories, newStory]);
                      setSelectedStoryId(newId);
                    }}
                    className="flex-1 bg-[#1e222a] hover:bg-[#282c35] hover:border-[#38bdf8] text-[#f0f3f6] border border-[#282c35] py-1.5 rounded text-xs font-semibold flex items-center justify-center gap-1 transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Story</span>
                  </button>
                </div>
              </div>
            </section>
          </div>
        </main>
      )}
    </div>
  );
}
