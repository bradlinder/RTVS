import React from 'react';
import ReactDOM from 'react-dom/client';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <div style={{ fontFamily: 'system-ui, sans-serif', padding: '2rem', textAlign: 'center' }}>
    <h1>Radio &amp; TV Segmenter v2.7.1</h1>
    <p>Desktop Application Repository &amp; PyInstaller Release Engine.</p>
  </div>
);
