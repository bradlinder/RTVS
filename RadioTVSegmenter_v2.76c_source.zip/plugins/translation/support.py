"""Small dependency-light helpers shared by the translation plugin runtime."""
from __future__ import annotations
import os, sys
from pathlib import Path
from PySide6.QtCore import QSettings

def get_app_data_dir() -> Path:
    if sys.platform == "win32":
        base = Path(os.environ.get("APPDATA") or Path.home() / "AppData" / "Roaming")
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share")
    p = base / "RadioTVSegmenter"
    p.mkdir(parents=True, exist_ok=True)
    return p

def get_models_storage_dir() -> Path:
    settings = QSettings("RadioTVSegmenter", "RadioTVStorySegmenter")
    custom = settings.value("models_dir", "")
    if custom and isinstance(custom, str) and custom.strip():
        p = Path(custom.strip())
        try:
            p.mkdir(parents=True, exist_ok=True)
            return p
        except Exception:
            pass
    p = get_app_data_dir() / "models"
    p.mkdir(parents=True, exist_ok=True)
    return p

def setup_windows_dll_directories() -> None:
    if sys.platform != "win32":
        return
    try:
        dll = Path(sys.prefix) / "Library" / "bin"
        if dll.is_dir() and hasattr(os, "add_dll_directory"):
            os.add_dll_directory(str(dll))
    except Exception:
        pass
